
var express = require('express');
var app = express();

var server = app.listen(3000);
	
app.use(express.static('public'));










var socket = require('socket.io');

var io = socket(server);

io.sockets.on('connection', newConnection);

function newConnection(socket) { 
	console.log('new connection: ' + socket.id);


	// if u get message called sendDots (what we defined at the public.framer prototype) -> do function DotMsg
	socket.on('sendDots', DotMsg); 

	function DotMsg(data) {
		socket.broadcast.emit('sendDots', data); // send from server to the other client
		console.log(data); 
		// io.sockets.emit('DotMsg', data); // send to all clients include the public file
	}






}


console.log('hello server');