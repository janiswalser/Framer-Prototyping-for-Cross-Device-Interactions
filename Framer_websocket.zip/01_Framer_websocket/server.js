
var express = require('express');
var app = express();

var server = app.listen(3000);
	
app.use(express.static('public.framer'));










var socket = require('socket.io');

var io = socket(server);

io.sockets.on('connection', newConnection); //When get a connection run the function newConnection

function newConnection(socket) { 

	console.log('new connection: ' + socket.id); //show me the id of every new connected client

	// if u get message called Msg (what we defined at the framer prototype) -> execute function DoSomething
	socket.on('Msg', DoSomething); 

	function DoSomething(data) {
		socket.broadcast.emit('Msg', data); // send the data from server to the other clients
		console.log(data); // print the data 
		// io.sockets.emit('Msg', data); // send to all clients include the public file
	}
}


console.log('Hello Server');